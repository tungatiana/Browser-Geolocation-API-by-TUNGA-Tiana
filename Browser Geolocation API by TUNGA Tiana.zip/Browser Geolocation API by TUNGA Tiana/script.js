const destLat = 48.8584; // Eiffel Tower
const destLon = 2.2945;

function getLocation() {
    const status = document.getElementById("status");
    
    if (navigator.geolocation) {
        status.innerText = "Requesting permission...";
        navigator.geolocation.getCurrentPosition(showPosition, handleError);
    } else {
        status.innerText = "Geolocation not supported.";
    }
}

function showPosition(position) {
    const status = document.getElementById("status");
    const userLat = position.coords.latitude;
    const userLon = position.coords.longitude;
    
    status.innerText = "Location found!";
    document.getElementById("lat").innerText = userLat.toFixed(4);
    document.getElementById("lon").innerText = userLon.toFixed(4);

    const dist = calculateDistance(userLat, userLon, destLat, destLon);
    document.getElementById("distance").innerText = dist.toFixed(2);
}

function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; 
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
}

function handleError(error) {
    const status = document.getElementById("status");
    status.innerText = "Error: Access Denied.";
}